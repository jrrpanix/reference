void print_col( const double *v , long c , long n , bool trans )
{
  for( long i = 0 ;i < n ; i++ )
    {
      long col = index( i , c , n , trans );
      std::cout << v[col] << std::endl;
    }
}


void print(  const double *v , long n , bool trans )
{
  for( long i = 0 ; i < n ; i++ )
    {
      for( long j = 0 ; j < n ; j++ )
	{
	  int ix = index( i , j , n, trans );
	  std::cout << v[ix] << " " ;
	}
      std::cout << std::endl;
    }
}

