
#include <vector>
#include <algorithm>
#include <numeric>
#include <iterator>
#include <iostream>
#include <sstream>
#include <queue>
#include <unistd.h>
#include <stdlib.h>
#include <calc/Time.h>
#include <pthread.h>
#include <time.h>
#include <atomic>
#include <stdint.h>

typedef long vtype;

class MyCond
{
public:
  MyCond()
  {
    pthread_cond_init( &loop_exit, NULL );
    pthread_mutex_init( &lock , NULL );
  }

  ~MyCond()
  {
    pthread_cond_destroy( &loop_exit );
    pthread_mutex_destroy( &lock );
  }

  pthread_cond_t  loop_exit;
  pthread_mutex_t lock;
};


//pthread_cond_t loop_exit = PTHREAD_COND_INITIALIZER;

std::atomic<vtype> GlobalI(0);
std::atomic<vtype> GlobalS(500000000);
std::vector<vtype> GlobalV(GlobalS);

class GlobalQ
{
public:
  GlobalQ() 
  {
    pthread_mutex_init( &lock , NULL );
  }

  void put( const std::string &s )
  {
    pthread_mutex_lock( &lock );
    q.push(s);
    pthread_mutex_unlock( &lock );
  }

  std::string get()
  {
    pthread_mutex_lock( &lock );
    std::string v = q.front();
    q.pop();
    pthread_mutex_unlock( &lock );
    return v;
  }

  bool empty() 
  {
    pthread_mutex_lock( &lock );
    bool rv = q.empty();
    pthread_mutex_unlock( &lock );
    return rv;
  }

  

private:
  std::queue<std::string>  q;
  mutable pthread_mutex_t  lock;
};

GlobalQ globalQ;

//-------------------------------------------------------
// 
//-------------------------------------------------------
class Symbol;
typedef std::vector<Symbol> SymbolVec;

class Symbol
{
public:

  Symbol() {}
  Symbol( int i , int b ) : id(i),burst(b) {}

public:
  int id;
  int burst;

  static int get_burst()
  {
    return 1 + rand() % 100;
  }

  static SymbolVec create_symbols( int nsym )
  {
    SymbolVec sV;
    for( int i = 0; i < nsym ; i++ )
      sV.push_back( Symbol( i , get_burst() ) );
    return sV;
  }
  
};

void timed_sleep( int id )
{
  struct timespec ts;
  struct timespec rem;
  ts.tv_sec=0;
  ts.tv_nsec=0; // 1000 microseconds;
  calc::Time t0 = calc::Time::now();
  nanosleep( &ts, &rem );
  calc::Time t1 = calc::Time::now();
  long us = (t1-t0)/calc::Time::ticks_per_usec() ;
  std::stringstream strm;
  strm << "sleep for id  " << id  << " = " << us ;
  globalQ.put(strm.str());
}

void *start_thr( void *p )
{
  int id = *(int *)p;
  vtype z(0) ;
  while( GlobalI < GlobalS ) 
    {
      z=++GlobalI;
      z--;
      GlobalV[z]=z;
    }
    
}

void *wait_example( void *p )
{
  calc::Time t0 = calc::Time::now();
  MyCond *cond =(MyCond *)p;
  pthread_cond_wait( &cond->loop_exit , &cond->lock );
  calc::Time t1 = calc::Time::now();
  long us = (t1-t0)/calc::Time::ticks_per_usec() ;
  std::cout << us << std::endl;
  pthread_mutex_unlock( &cond->lock );
}

void *send_wakeup( void *p )
{
  struct timespec ts;
  struct timespec rem;
  MyCond *cond =(MyCond *)p;
  ts.tv_sec=0;
  ts.tv_nsec=1000*500; // 500 microseconds;
  nanosleep( &ts, &rem );
  pthread_cond_broadcast( &cond->loop_exit );
}

void wake_test()
{
  MyCond cond;
  std::vector<pthread_t> tv;
  for( int i = 0 ; i < 10  ; i++ )
    {
      pthread_t thr1 ;
      pthread_create( &thr1  , (pthread_attr_t *)NULL , wait_example , (void * )&cond );
      tv.push_back( thr1 );
    }
  pthread_t thr2 ;
  pthread_create( &thr2  , (pthread_attr_t *)NULL , send_wakeup , (void * )&cond );
  tv.push_back( thr2 );
  for( int i = 0 ;i < tv.size() ;i++ )
    pthread_join( tv[i] , (void **)NULL);
}

void drive( int nthr )
{
  std::vector<pthread_t> tv;
  std::vector<int *> iv;
  for( int i = 0 ; i < nthr ; i++ )
    {
      iv.push_back( new int );
      *(iv.back())=i;
      pthread_t thr ;
      pthread_create( &thr  , (pthread_attr_t *)NULL , start_thr , (void * )iv.back() );
      tv.push_back(thr);
    }
  for( int i = 0; i < tv.size() ; i++ )
    pthread_join( tv[i] , (void **)NULL);

  while( globalQ.empty() == false )
    {
      std::cout << globalQ.get() << std::endl;
    }

}



//------------------------------------------------------------
// 
//------------------------------------------------------------
int main( int argc , char **argv )
{
  std::atomic<int64_t> i64;
  std::atomic<char> c64;
  std::atomic<int64_t *> p64;
  //std::cout << "lock free is " << (p64.is_lock_free() ? "true" : "false") << std::endl;
  if ( argc != 3 )
    {
      std::cerr << "usage : "  << argv[0] << " <nsymbols> <nthreads>" << std::endl;
      return -1;
    }
  int nsym = atoi( argv[1] );
  int nthr = atoi( argv[2] );
  wake_test();
  /*
  calc::Time t0 = calc::Time::now();
  drive(nthr);
  calc::Time t1 = calc::Time::now();
  long us = (t1-t0)/calc::Time::ticks_per_usec() ;
  //long sum = std::accumulate( GlobalV.begin() , GlobalV.end() , 0 );
  long sum = 0 ;
  for( int i = 0 ; i < GlobalV.size() ; i++ )
    {
      sum += i;
      //if ( i < 1000 ) std::cout << i << std::endl;
    }
  double op = (double)us / (double)GlobalS;
  std::cout << "GlobalI = " << GlobalI << " total time = " << us << " sum = " << sum << " " << op << std::endl;
  */
  return 0;
}
