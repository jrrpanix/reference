
#include <vector>
#include <algorithm>
#include <numeric>
#include <iterator>
#include <iostream>
#include <sstream>
#include <queue>
#include <unistd.h>
#include <stdlib.h>
#include <calc/Time.h>
#include <pthread.h>
#include <time.h>
#include <atomic>
#include <memory>
#include <vector>

//---------------------------------------------------------
//  Thread Data
//---------------------------------------------------------

typedef std::pair<int,int> ThrData;

//---------------------------------------------------------
// Thread Data Q
//---------------------------------------------------------
class ThrDataQ
{
public:
  void push( const ThrData &x ) 
  { q_.push(x); }

  ThrData pop()
  {
    ThrData d = q_.front();
    q_.pop();
    return d;
  }

  bool empty() const
  { return q_.empty(); }

  size_t size() const
  { return q_.size(); }

private:
  std::queue<ThrData> q_;
};

typedef std::shared_ptr<ThrDataQ> ThrDataQPtr;

//---------------------------------------------------------
// Consumer 
//---------------------------------------------------------
class Consumer
{
public:
  Consumer( int x ) : key(x) {}
public:
  int              key;
  std::vector<int> numbers;
};

typedef std::shared_ptr<Consumer> ConsumerPtr;
typedef std::vector<ConsumerPtr>  ConsumerVec;

//---------------------------------------------------------
// Thread Condition Variable
//---------------------------------------------------------
class ThrCond
{
public:
  ThrCond() :run_(true)  { init(); }
  ~ThrCond() { destroy(); }
public:
  bool run() volatile const 
  { return run_; }

  void stop() volatile
  { run_=false; }
public:
  pthread_cond_t  *cond() { return &cond_; }
  pthread_mutex_t *lock() { return &lock_; }
private:
  pthread_cond_t  cond_;
  pthread_mutex_t lock_;
  bool            run_;
private:
  void init()
  {
    pthread_cond_init( &cond_, NULL );
    pthread_mutex_init( &lock_ , NULL );
  }

  void destroy()
  {
    pthread_cond_destroy( &cond_ );
    pthread_mutex_destroy( &lock_ );
  }
};

typedef std::shared_ptr<ThrCond> ThrCondPtr;

//---------------------------------------------------------
// Thread Manager for Consumer Thread
//---------------------------------------------------------
class ThrMgr
{
public:
  ThrMgr( const ThrDataQPtr &q , 
	  const ConsumerVec &cV ,
	  const ThrCondPtr  &cond )
    :q_(q),cV_(cV),cond_(cond) 
  {}

public:
  void run()
  {
    if ( cV_.empty() ) return;
    while( cond_->run() )
      {
	wait();
      }
  }

  ThrDataQPtr q()    { return q_; }
  ThrCondPtr  cond() { return cond_; } 
  int         start_cons() { return cV_.front()->key ; }

public:
  pthread_t thr;

private:
  ThrDataQPtr q_;
  ConsumerVec cV_;
  ThrCondPtr  cond_;

private:
  void wait()
  {
    //std::cout << "wait on run = " << cond_->run() << std::endl;
    pthread_cond_wait(cond_->cond() , cond_->lock() );
    //std::cout << "out of wait run = " << cond_->run() << std::endl;
    emptyq();
    pthread_mutex_unlock(cond_->lock());
  }

  void emptyq()
  {
    int start_consumer = cV_.front()->key;
    while( q_->empty() == false && cond_->run() )
      {
	ThrData d = q_->pop();
	int indx = d.first - start_consumer;
	cV_[indx]->numbers.push_back( d.second );
      }
  }

};

typedef std::shared_ptr<ThrMgr> ThrMgrPtr;
typedef std::vector<ThrMgrPtr>  ThrMgrVec;


//---------------------------------------------------------
// ProducerManger
//---------------------------------------------------------
class ProducerMgr
{
public:
  ProducerMgr( int ncons , const ThrMgrVec &thrV) 
  : stop_(false),ncons_(ncons),consThr_(thrV) 
  {}

public:
  void stop() volatile
  { stop_=true; }

public:
  void run()
  {
    cons_per_thr_ = ncons_/consThr_.size();
    while( stop_ == false )
      {
	putQ();
      }
    shutdown();
  }

public:
  pthread_t thr;

private:
  bool       stop_;
  int        ncons_;
  int        cons_per_thr_;
  ThrMgrVec  consThr_;

private:
  int get_cons()   
  { return rand() % ncons_; }

  int get_num() 
  { return rand() % 1000 ; } 

  void putQ()
  {
    ThrData d(get_cons(),get_num());
    // find the right q;
    int i = d.first / cons_per_thr_;
    if ( i == consThr_.size() ) i--;
    
    ThrMgrPtr m = consThr_[i];
    // keep trying until q is free
    while( pthread_mutex_trylock( m->cond()->lock() ) == EBUSY ) ;
    // push new data on
    m->q()->push(d);
    // signal consumer 
    pthread_mutex_unlock(m->cond()->lock());
    pthread_cond_signal( m->cond()->cond());
  }
  
  void shutdown()
  {
    for( size_t i = 0 ; i < consThr_.size(); i++ )
      {
	ThrMgrPtr m = consThr_[i];
	while( pthread_mutex_trylock( m->cond()->lock() ) == EBUSY ) ;
	consThr_[i]->cond()->stop();
	pthread_mutex_unlock(m->cond()->lock());
	pthread_cond_signal( m->cond()->cond());
      }
  }


};

//------------------------------------------------------------
//
//------------------------------------------------------------
void create_consumers(int nsym , ConsumerVec &cV )
{
  for( int i = 0 ; i < nsym ; i++ ) 
    cV.push_back( ConsumerPtr( new Consumer(i) ) );
}

void *run_consumer( void *p )
{
  ThrMgrPtr mgr = *(ThrMgrPtr *)(p);
  mgr->run();
}

void create_consumer_threads( int nthr , const ConsumerVec &cV , ThrMgrVec &thrVec )
{
  size_t i = 0 , end_i = cV.size();
  int cons_per_thr = end_i / nthr;
  if ( cons_per_thr == 0 ) cons_per_thr = 1;
  while( i != end_i )
    {
      ConsumerVec consumersForThread;
      for( size_t j = 0 ; j < cons_per_thr && i != end_i ; i++,j++ )
	consumersForThread.push_back( cV[i] );
      int rem = end_i - i;
      if ( rem < cons_per_thr )
	for( ; i < end_i ; i++ )
	  consumersForThread.push_back( cV[i] );
      if ( consumersForThread.empty() )
	break;
      //      std::cout << consumersForThread.front()->key  
      //<< " " 
      //		<< consumersForThread.back()->key 
      //<< " "
      //<< i
      //<< std::endl;
      ThrDataQPtr thrQ( new ThrDataQ() );
      ThrCondPtr thrCond( new ThrCond() );
      ThrMgrPtr thrMgr( new ThrMgr( thrQ , consumersForThread , thrCond ) );
      thrVec.push_back( thrMgr );
      ThrMgrPtr *thr_mgr = new ThrMgrPtr(thrMgr);
      pthread_create( &thrMgr->thr , (pthread_attr_t *)NULL , run_consumer , ( void * )thr_mgr );
    }
}

void *run_producer( void *p)
{
  ProducerMgr *mgr = (ProducerMgr *)(p);
  mgr->run();
}

void create_producer_thread( const ThrMgrVec &thrVec , const ConsumerVec &cV , ProducerMgr &prod )
{
  pthread_create( &prod.thr , (pthread_attr_t *)NULL , run_producer , (void *)&prod );
}

void run( int nsym , int nthr , int runtime )
{
  ConsumerVec cV ;
  create_consumers( nsym , cV );
  
  ThrMgrVec thrVec;
  create_consumer_threads( nthr , cV , thrVec );  

  ProducerMgr prod(nsym , thrVec );
  create_producer_thread( thrVec , cV , prod );

  sleep(runtime);
  prod.stop();

  pthread_join( prod.thr  , (void **)NULL);
  for( size_t i = 0 ; i < thrVec.size() ; i++ )
    pthread_join( thrVec[i]->thr  , (void **)NULL);

  long sum = 0;
  for( int i = 0 ; i < cV.size() ; i++ )
    sum += cV[i]->numbers.size();
  
  std::cout << "total msg = " << sum << " sym=" << nsym << " nthr = " << nthr << std::endl;

}


//------------------------------------------------------------
// 
//------------------------------------------------------------
int main( int argc , char **argv )
{
  if ( argc != 3 )
    {
      std::cerr << "usage " << argv[0] << " <symbols> <seconds>" << std::endl;
      return -1;
    }
  int nsym = atoi(argv[1]);
  int nsec = atoi(argv[2]);

  for( int i = 1 ; i <= nsym ;i++ )
    {
      int nthr = i;
      run(nsym,nthr,nsec);
    }
}
