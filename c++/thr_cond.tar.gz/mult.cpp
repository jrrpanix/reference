
#include <vector>
#include <algorithm>
#include <numeric>
#include <iterator>
#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <calc/Time.h>
#include <armadillo>
#include <pthread.h>

class Work
{
public:
  Work( long ri , long cj , long nr , long nc , long n , const double *rm , const double *cm , double *R )
    :
    ri_(ri),
    cj_(cj),
    nr_(nr),
    nc_(nc),
    n_(n),
    rm_(rm),
    cm_(cm),
    R_(R)
  {}

  Work() {}
  
public:


  long         ri_;
  long         cj_;
  long         nr_;
  long         nc_;
  long         n_;
  const double *rm_;
  const double *cm_;
  double       *R_;
};

typedef std::vector<Work> WorkVec;

double rand_dbl()
{
  static double RM = RAND_MAX;
  return (double) rand() / RM;
}

double *allocate( long N )
{
  return new double[N];
}

void clear( double *v )
{ delete [] v; }

void assign( double *v , long n )
{ std::generate( &v[0] , &v[0] + n*n , rand_dbl ); }
  
inline double mult_r_x_c( const double *r , const double *c , long n )
{
  register double p = 0.0;
  register long i , j;
  for (i=0,j=1 ; j < n ; i += 2 , j += 2)
    {
      register double a1 = c[i] * r[i];
      register double a2 = c[j] * r[j];
      p += a1 + a2;
    }
  if ( i < n )
    p += c[i] * r[i];
  return p;
}

void create_map( const double *rm , const double *cm , double *R , long n , int n_thr , WorkVec &wV )
{
  long chunks = n / n_thr;
  long stub = n - n_thr*chunks;
  int j = 1 ;
  long row_i = 0 ;
  for( long row_i = 0 , j = 1 , nr = 0 ; row_i < n ; row_i += nr , j++ )
    {
      nr = j == n_thr ? chunks + stub : chunks;
      wV.push_back( Work(  row_i , 0, nr , n , n , rm , cm , R ));
    }
}

void *process_work( void *thread_data )
{
  Work &w = *(Work *)thread_data;
  long offset = w.ri_ * w.n_;
  const double *r = w.rm_ + offset;
  double *R = w.R_ + offset ;

  for( long i = 0 , k = 0 ; i < w.nr_ ; i++ )
    {
      const double *c = w.cm_ ;
      for( long j = 0 ; j < w.nc_ ; j++ , k++ )
	{
	  R[k] = mult_r_x_c(r,c,w.n_);
	  c += w.n_;
	}
      r += w.n_;
    }
  return thread_data;
}

void reduce( WorkVec &wV )
{
  std::vector<pthread_t> tv;
  for( int i = 0; i < wV.size(); i++ )
    {
      pthread_t thr ;
      Work &w = wV[i];
      pthread_create( &thr  , (pthread_attr_t *)NULL , process_work , (void * )(&w) );
      tv.push_back(thr);
    }
  for( int i = 0; i < tv.size() ; i++ )
    pthread_join( tv[i] , (void **)NULL);

}

void parallel( int nthr , long n )
{
  const long N = n;
  // create an NxN matrix of random numbers row major format

  double *rm = allocate(N*N);
  assign( rm , N );

  // create an NxN matrix of random numbers col major format
  double *cm = allocate(N*N);
  assign( cm , N );

  // create an NxN matrix to hold the result of rm * cm
  double *R = allocate(N*N);

  //
  WorkVec wV;
  calc::Time t0 = calc::Time::now();
  create_map( rm , cm , R , N , nthr , wV );
  reduce( wV );
  calc::Time t1 = calc::Time::now();
  std::cout << N << "x" << N << " map reduce with " 
	    << nthr << " threads completed in " 
	    << (t1-t0)/calc::Time::ticks_per_msec() << " ms" << std::endl;

  clear( rm );
  clear( cm );
  clear( R );
  
}

int main( int argc , char **argv )
{
  if ( argc < 4 )
    {
      std::cerr << "usage " << argv[0] << " <matrix_size> <nthreads0> <nhtreads1>" << std::endl;
      return 0;
    }
  long n = atol( argv[1] );
  int t1 = atoi( argv[2] );
  int t2= atoi( argv[3] );
  for( int i = t1 ; i <= t2 ; i++ )
    parallel( i , n );
} 

