
#include <calc/Time.h>
#include <iostream>
#include <algorithm>
#include <pthread.h>

typedef double (*F_PTR)(double,double);


class RunData
{
public:
  RunData( double beg , double end , double ncalc , F_PTR fun )
    :b(beg),e(end),nc(ncalc),f(fun)
  {}

  double b;
  double e;
  double nc;
  F_PTR  f;
  double psum;

};

double exp_neg( double i , double nc)
{
  return exp(-i/nc);
}


double partial_sum( double b , double e , double nc , F_PTR fptr )
{
  double sum = 0.0;
  for( double i = b ; i < e ; i += 1.0 )
    sum += fptr(i,nc);
  return sum;
}

void *run_compute( void *pdata )
{
  sleep(3);
  RunData *run_data = (RunData *)(pdata);
  run_data->psum = partial_sum( run_data->b , run_data->e , run_data->nc, run_data->f );
  return pdata;
}

double thr_run( int n_thr , double n_calcs , F_PTR fptr )
{
  calc::Time t0 = calc::Time::now();
  std::vector<pthread_t> tv;
  std::vector<RunData *> rd;
  double slice_per_thread = n_calcs / (double)n_thr;
  double beg = 0 ;
  for( int i = 0; i < n_thr ; i++ )
    {
      double e = beg + slice_per_thread;
      RunData *d = new RunData( beg , e , n_calcs , fptr);
      pthread_t thr ;
      pthread_create( &thr  , (pthread_attr_t *)NULL , run_compute , (void * )d );
      tv.push_back(thr);
      rd.push_back(d);
      beg = e;
    }

  for( int i = 0; i < tv.size() ; i++ )
    pthread_join( tv[i] , (void **)NULL);
  double total = 0.0;
  for( int i = 0; i < rd.size() ; i++ )
    { 
      total += rd[i]->psum;
      delete rd[i];
    }
  calc::Time t1 = calc::Time::now();
  long ms = (t1-t0)/calc::Time::ticks_per_msec() ;
  std::cout << n_thr << "," << n_calcs << "," << ms << "," << total << std::endl;
  return total;
}



int main( int argc , char **argv )
{
  thr_run( 1 , 1e8 , exp_neg );
  thr_run( 4 , 1e8 , exp_neg );
  thr_run( 8 , 1e8 , exp_neg );
  thr_run( 16 , 1e8 , exp_neg );
  thr_run( 32 , 1e8 , exp_neg );
  thr_run( 64 , 1e8 , exp_neg );
  thr_run( 128 , 1e8 , exp_neg );
  thr_run( 256 , 1e8 , exp_neg );
  thr_run( 512 , 1e8 , exp_neg );
  thr_run( 1000 , 1e8 , exp_neg );
  thr_run( 2000 , 1e8 , exp_neg );
  thr_run( 5000 , 1e8 , exp_neg );
  thr_run( 8000 , 1e8 , exp_neg );
}
