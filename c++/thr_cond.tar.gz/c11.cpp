#include <iostream>
#include <thread>

void hello()
{
  std::cout << "hello" << std::endl;
}

int main( int , char ** )
{
  std::thread t(hello);
  t.join();
}
