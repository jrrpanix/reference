
void mult( const double *rm , const double *cm , long n , double *R )
{
  for( long i = 0,k = 0 ; i < n ;i++ )
    {
      const double *r = &rm[i];
      register long j0,j1;
      for( j0=0 ; j0  < n ; j0++ , k++ )
	R[k] = mult_r_x_c(r,&cm[j0],n);
    }
}


void mult_test()
{
  const long N = 1000;
  double *rm = init( N );
  double *cm = init( N );
  double *R = init( N );
  assign( rm , N );
  assign( cm , N );
  calc::Time t0 = calc::Time::now();
  mult( rm , cm , N , R );
  calc::Time t1 = calc::Time::now();
  std::cout << N << "x" << N << " matrix mult0 in " << (t1-t0)/calc::Time::ticks_per_msec() << " ms" << std::endl;
}

void atest()
{
  const long N = 1000;
  arma::mat A = arma::randu<arma::mat>(N,N);
  calc::Time t0 = calc::Time::now();
  arma::mat AT = A.t();
  calc::Time t1 = calc::Time::now();
  std::cout << N << "x" << N << " matrix trans via arma in " << (t1-t0)/calc::Time::ticks_per_msec() << " ms" << std::endl;
  t0 = calc::Time::now();
  arma::mat C = AT*A;
  t1 = calc::Time::now();
  std::cout << N << "x" << N << " matrix mult via arma in " << (t1-t0)/calc::Time::ticks_per_msec() << " ms" << std::endl;
}
