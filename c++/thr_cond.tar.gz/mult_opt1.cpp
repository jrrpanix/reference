
#include <vector>
#include <algorithm>
#include <numeric>
#include <iterator>
#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <calc/Time.h>
#include <armadillo>

class Work
{
public:
  Work( long ri , long cj , long nr , long nc , long n , const double *rm , const double *cm , double *R )
    :
    ri_(ri),
    cj_(cj),
    nr_(nr),
    nc_(nc),
    n_(n),
    rm_(rm),
    cm_(cm),
    R_(R)
  {}

  Work() {}
  
public:


  long         ri_;
  long         cj_;
  long         nr_;
  long         nc_;
  long         n_;
  const double *rm_;
  const double *cm_;
  double       *R_;
};

typedef std::vector<Work> WorkVec;

double rand_dbl()
{
  static double RM = RAND_MAX;
  return (double) rand() / RM;
}

double *init( long n )
{ return new double [n*n]; }

void assign( double *v , long n )
{ std::generate( &v[0] , &v[0] + n*n , rand_dbl ); }
  
inline double mult_r_x_c_0( const double *r , const double *c , long n )
{
  register double p = 0.0;
  register long i = 0 ;
  while ( i < n - 3 )
    {
      register double a1 = c[i] * r[i];
      register double a2 = c[i+1] * r[i+1];
      register double a3 = c[i+2] * r[i+2];
      register double a4 = c[i+3] * r[i+3];
      p += a1 + a2 + a3 + a4;
      i += 4;
    }
  while( i < n ) { p += c[i] * r[i]; i++; }
  return p;
}

inline double mult_r_x_c_1( const double *r , const double *c , long n )
{
  register double p = 0.0;
  register long i , j;
  for (i=0,j=1 ; j < n ; i += 2 , j += 2)
    {
      register double a1 = c[i] * r[i];
      register double a2 = c[j] * r[j];
      p += a1 + a2;
    }
  if ( i < n )
    p += c[i] * r[i];
  return p;
}


double mult_r_x_c_2( const double *r , const double *c , long n )
{
  double p = 0.0;
  long i = 0 ;
  while( i < n ) { p += c[i] * r[i]; i++; }
  return p;
}

double mult( const double *rm , const double *cm , long n , double *R )
{
  register double x;
  for( long i = 0,k = 0 ; i < n ;i++ )
    {
      const double *r = &rm[i];
      register long j0,j1;
      for( j0=0 ; j0  < n ; j0++ , k++ )
	R[k] = mult_r_x_c_1(r,&cm[j0],n);
    }
  return x;
}


void create_map()
{
}

void mult_test()
{
 const long N = 1000;
  double *rm = init( N );
  double *cm = init( N );
  double *R = init( N );
  assign( rm , N );
  assign( cm , N );
  calc::Time t0 = calc::Time::now();
  mult( rm , cm , N , R );
  calc::Time t1 = calc::Time::now();
  std::cout << N << "x" << N << " matrix mult0 in " << (t1-t0)/calc::Time::ticks_per_msec() << " ms" << std::endl;
}

void atest()
{
  const long N = 1000;
  arma::mat A = arma::randu<arma::mat>(N,N);
  calc::Time t0 = calc::Time::now();
  arma::mat AT = A.t();
  calc::Time t1 = calc::Time::now();
  std::cout << N << "x" << N << " matrix trans via arma in " << (t1-t0)/calc::Time::ticks_per_msec() << " ms" << std::endl;
  t0 = calc::Time::now();
  arma::mat C = AT*A;
  t1 = calc::Time::now();
  std::cout << N << "x" << N << " matrix mult via arma in " << (t1-t0)/calc::Time::ticks_per_msec() << " ms" << std::endl;
}

int main( int argc , char **argv )
{
  atest();
  mult_test();
} 

