
#include <calc/Time.h>
#include <calc/Random.h>
#include <iostream>
#include <algorithm>
#include <pthread.h>
#include <map>


class RunData
{
public:
  RunData( int ni , int ng )
    :num_iter(ni),num_gen(ng) {}

  int      num_iter; // number of times calling "compute_random"
  int      num_gen;  // number of random numbers to generate
};


long compute_random( int num_gen )
{
  const int N = num_gen;
  const int seed = 5113;

  calc::Time t0 = calc::Time::now();
  std::vector<double> V(N);
  calc::NormalGen ngen( seed , 0 , 1 );
  for( int i = 0 ; i < V.size() ; i++ )
    V[i] = ngen();

  std::sort(V.begin(),V.end());
  calc::Time t1 = calc::Time::now();
  return (t1-t0)/calc::Time::ticks_per_msec() ;
}

void *run_compute( void *pdata )
{
  sleep(3);
  RunData *run_data = (RunData *)(pdata);
  const int num_iter = run_data->num_iter;
  const int num_gen = run_data->num_gen;
  for( int i = 0 ; i < num_iter ; i++ )
    {
      compute_random(num_gen);
    }
  return pdata;
}

void thr_run( int n_thr , int num_iter , int num_gen )
{
  std::vector<pthread_t> tv;
  std::vector<RunData *> rd;
  for( int i = 0; i < n_thr ; i++ )
    {
      std::cout << "thr " << i << std::endl;
      RunData *d = new RunData( num_iter , num_gen );
      pthread_t thr ;
      pthread_create( &thr  , (pthread_attr_t *)NULL , run_compute , (void * )d );
      tv.push_back(thr);
      rd.push_back(d);
    }

  for( int i = 0; i < tv.size() ; i++ )
    pthread_join( tv[i] , (void **)NULL);
  for( int i = 0; i < rd.size() ; i++ )
    delete rd[i];
}

void grouping( int n_calls , int n_thr , int num_iter , int num_gen )
{
  calc::Time t0 = calc::Time::now();
  for( int i = 0 ; i < n_calls ; i++ )
    {
      thr_run( n_thr , num_iter , num_gen );
    }
  calc::Time t1 = calc::Time::now();
  double total_work = n_calls * n_thr * num_iter * num_gen ;
  long ms = ( (t1-t0)/calc::Time::ticks_per_msec() );
  std::cout << n_calls << "," << n_thr << "," << num_iter << "," << num_gen << " , " << ms << ", " << total_work << std::endl;
}

int main( int argc , char **argv )
{
  grouping( 8 , 4  , 100 , 100000 );
  grouping( 4 , 8  , 100 , 100000 );
  grouping( 2 , 16 , 100 , 100000 );
  grouping( 1 , 32 , 100 , 100000 );
  grouping( 1 , 64 , 100 , 50000 );
  grouping( 1 , 128 , 100 , 25000 );
  grouping( 1 , 256 , 100 , 12500 );
  grouping( 1 , 512 , 50 , 12500 );
}
