
#include <vector>
#include <algorithm>
#include <numeric>
#include <iterator>
#include <iostream>
#include <sstream>
#include <queue>
#include <unistd.h>
#include <stdlib.h>
#include <calc/Time.h>
#include <pthread.h>
#include <time.h>
#include <atomic>

class MyCond
{
public:
  MyCond()
    :max(0)
  {
    pthread_cond_init( &cond, NULL );
    pthread_mutex_init( &lock , NULL );
    start_=stop_=false;
  }

  ~MyCond()
  {
    pthread_cond_destroy( &cond );
    pthread_mutex_destroy( &lock );
  }

  bool start() const volatile { return start_; }
  bool stop()  const volatile { return stop_; }

  void start( bool x ) { start_=x; }
  void stop( bool x ) { stop_=x; }

  pthread_cond_t  cond;
  pthread_mutex_t lock;

  std::atomic<long> max;

private:
  bool start_;
  bool stop_;
};


class RunData
{
public:
  RunData() : cond(0),count(0) {}
  RunData( MyCond *c , int i ) : cond(c),id(i),count(0) {}
public:
  MyCond    *cond;
  int       id;
  int       priority;
  int       policy;
  int       low_p;
  int       high_p;
  long      count;
  pthread_t thr;
};


std::string get_sch_str( int policy )
{
  switch( policy )
    {
    case SCHED_FIFO:  return "FIFO";
    case SCHED_RR:    return "RR";
    case SCHED_OTHER: return "OTHER";
    }
  return std::string();
}

std::pair<int,int> get_sch_range( int policy )
{
  return std::pair<int,int>( sched_get_priority_min( policy ) , sched_get_priority_max( policy ) );
}

void *wait_on_cond( void *pd )
{
  RunData *rd = (RunData *)pd;
  MyCond *cond = rd->cond;
  pthread_cond_wait( &cond->cond , &cond->lock );
  pthread_mutex_unlock( &cond->lock );
  int last_p = rd->priority;
  struct sched_param *p = new sched_param();
  while( !cond->start() ) {}
  while( !cond->stop() ) 
    { 
      rd->count++;
      if ( false && rd->policy == SCHED_FIFO && rd->count % 50000 == 0 )
	{
	  struct timespec ts;
	  struct timespec rem;
	  ts.tv_sec=0;
	  ts.tv_nsec= 1;
	  nanosleep( &ts, &rem );
	  //p->sched_priority = rd->priority == rd->low_p ? rd->high_p : rd->low_p;
	  //int old = rd->priority;
	  //rd->priority = p->sched_priority ;
	  //hstd::cout << rd->thr << " " << rd->priority << std::endl;
	  //pthread_setschedparam( rd->thr , SCHED_FIFO , p );
	}
    }
}

void *send_wakeup( void *p )
{
  struct timespec ts;
  struct timespec rem;
  MyCond *cond =(MyCond *)p;
  long us_sleep = 10;
  ts.tv_sec=0;
  ts.tv_nsec= 1000 * us_sleep ;
  nanosleep( &ts, &rem );
  //std::cout <<"wake up threads " << std::endl;
  pthread_cond_broadcast( &cond->cond );
  nanosleep( &ts, &rem );
  //std::cout <<"start loop " << std::endl;
  cond->start(true);
  ts.tv_sec=2;
  nanosleep( &ts, &rem );
  //std::cout <<"stop " << std::endl;
  cond->stop(true);
}

std::vector<RunData *> create_wait_threads( MyCond &cond , int nthr , std::vector<pthread_t> &tv , int policy )
{
  std::vector<RunData *> rV;
  for( int i = 0 ; i < nthr  ; i++ )
    {
      RunData *rd = new RunData( &cond , i );
      pthread_t thr1 ;
      pthread_attr_t attr;
      pthread_attr_init( &attr );
      pthread_attr_setinheritsched( &attr , PTHREAD_EXPLICIT_SCHED);
      //      int scope;
      //pthread_attr_getscope( &attr , &scope );
      //std::cout << "scope = " << scope << " " << (scope == PTHREAD_SCOPE_SYSTEM ? "SYSTEM" : "NON-SYS") << std::endl;
      rd->priority = 99;
      rd->low_p = 92;
      rd->high_p = 98;
      rd->policy = policy;
      struct sched_param sch;
      if ( rd->policy == SCHED_FIFO || rd->policy == SCHED_RR )
	{
	  sch.sched_priority=rd->priority;
	  int rv;
	  rv = pthread_attr_setschedpolicy( &attr , policy );
	  rv = pthread_attr_setschedparam( &attr , &sch );
	}
      pthread_create( &thr1  , &attr , wait_on_cond , (void * )rd );
      tv.push_back( thr1 );
      rV.push_back(rd);
    }
  return rV;
}

void create_signal_thr( MyCond &cond , std::vector<pthread_t> &tv )
{
  pthread_t thr ;
  pthread_create( &thr  , (pthread_attr_t *)NULL , send_wakeup , (void * )&cond );
  tv.push_back( thr );
}


void wake_test( int priority , long &t)
{
  MyCond cond;
  std::vector<pthread_t> tv;
  std::vector<RunData *> rV = create_wait_threads(cond,10,tv,priority);
  create_signal_thr(cond,tv);
  for( int i = 0 ;i < tv.size() ;i++ )
    pthread_join( tv[i] , (void **)NULL);
  long sum = 0;
  for( int i = 0 ; i < rV.size() ;i++ )
    {
      //std::cout << rV[i]->id << " " << rV[i]->count << std::endl;
      sum += rV[i]->count;
    }
  t += sum;
  //std::cout << "Total = " << sum << std::endl;
}


//------------------------------------------------------------
int main( int argc , char **argv )
{
  long o=0,r=0,f=0;
  for( int i = 0; i < 10; i++ )
    {
      wake_test(SCHED_OTHER,o);
      wake_test(SCHED_RR,r);
      wake_test(SCHED_FIFO,f);
    }
  std::cout << o << std::endl;
  std::cout << r << std::endl;
  std::cout << f << std::endl;
  return 0;
}
